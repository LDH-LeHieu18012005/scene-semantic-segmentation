# Biên bản rà soát nội dung báo cáo

Ngày kiểm tra: 28/10/2026. Tài liệu kiểm tra: `BAO_CAO_HOAN_THIEN_LE_DUONG_HIEU.docx`, theo định dạng mẫu người dùng đã chọn.

## Kết luận trong phạm vi kiểm tra

Không phát hiện việc tự tạo hoặc chép sai các số liệu ở các bảng kết quả chính đã đối chiếu. Có 97 phép kiểm tra số liệu đạt, gồm 9 mô hình, các phép trừ mIoU, tham số, MACs, latency, IoU từng lớp, khoảng tin cậy và các tỉ lệ tăng được nêu trong phần phân tích. Các số này có nguồn trong output notebook hiện có; đây không phải chứng nhận rằng toàn bộ thí nghiệm đã được tái lập độc lập.

Có một thông tin thực tế bị ghi sai rõ ràng: bản trước ghi thiếu checkpoint b7 dù file hiện có trên máy. Ngoài ra có dẫn chiếu hình không còn đúng sau khi tách lưới ảnh, cùng một số mô tả chưa đủ chính xác về kiểm thử và phương pháp. Đã sửa/làm rõ tổng cộng 15 vị trí, giữ nguyên các kết quả đo.

## Những gì đã đối chiếu

| Nhóm | Bằng chứng đã đọc | Kết quả |
|---|---|---|
| Văn bản báo cáo | Nội dung trích trực tiếp từ DOCX, 18 bảng và 10 công thức | Đã đọc các phần đầu, bốn chương, kết luận, tài liệu tham khảo và phụ lục |
| Modal | Ba notebook gốc, source nhúng, output đánh giá/benchmark và bảng tổng hợp | mIoU, CI, tham số, MACs, latency, gate và dữ liệu lớp khớp |
| Kaggle | Ba notebook gốc; cấu hình cell 4, runner cell 6, bản vá cell 8, output cell 14/18 | Các số trong bảng chính khớp; có resume và bản vá ngoài hash nguồn |
| Kiến trúc | pspnet_lab.py, KagglePSPNet nhúng, semseg/model/pspnet.py và resnet.py | PPM, sáu gate, ba nhánh atrous, số kênh và auxiliary head phù hợp mô tả |
| Dữ liệu/metric | read_mask, prepare, confusion, metrics, predict và paired_bootstrap | Ánh xạ nhãn, mIoU toàn tập, window merge và phạm vi bootstrap đúng |
| Demo | inference.py, server.py, validate.py, browser_check.mjs, JSON và ảnh đã lưu | Chức năng có triển khai; phạm vi kiểm tra phải được diễn đạt hẹp hơn kiểm thử đầy đủ |
| Checkpoint | File cục bộ b7, kích thước và SHA256 mới tính | 546.162.205 byte; hash khớp notebook và artifact demo |
| Cơ sở lý thuyết | Các bài gốc PSPNet, FCN, DeepLabV3, ResNet; tài liệu API TorchVision; repo semseg cố định commit | Không phát hiện công trình hoặc tên mô hình bị bịa; không gán điểm dự án thành điểm bài báo |

## Danh sách sửa/làm rõ

| Mã | Vị trí | Vấn đề của bản trước | Nội dung đã sửa |
|---|---|---|---|
| C01 | Mục 3.8 | Ghi không có checkpoint b7 | Ghi đúng file đang có, kích thước/hash; vẫn thiếu thống kê từng ảnh và các checkpoint/init khác để kiểm tra đầy đủ |
| C02 | Mục 4.7.4 | Lặp lại thông tin sai về checkpoint | Phân biệt đã xác minh byte/hash với chưa chạy lại strict loading và suy luận |
| C03 | Mục 4.7.4 | Có thể hiểu kiểm tra trình duyệt đã xác nhận tải file thật | Nêu kiểm tra download chỉ xác nhận href là PNG data URI |
| C04 | Bảng 4.9 | Mô tả kiểm tra tải PNG quá rộng | Đổi thành kiểm tra liên kết dữ liệu PNG |
| C05 | Mục 3.5 | Chưa nói rõ giới hạn tái lập dù có seed/RNG | Bổ sung cuDNN autotune tắt deterministic trong train, không bảo đảm tái lập từng bit |
| C06 | Mục 2.6 | Chỉ số t của lịch LR dễ bị hiểu update cuối dùng LR bằng 0 | Nêu t cuối là 9.999; LR trước update cuối vẫn dương rất nhỏ |
| C07 | Bảng 3.2 | Ô warmup/clip Modal ghi mơ hồ | Ghi rõ không warmup, không clip gradient; clip_grad_norm với ngưỡng vô hạn chỉ đo norm |
| C08 | Mục 4.5 | Dẫn chiếu một hình sau khi lưới đã tách; metric theo ảnh chưa rõ | Dẫn ba hình 4.7–4.9; chỉ rõ lớp được tính là union>0, gồm lớp chỉ có trong prediction |
| C09 | Mục 4.5 | Có suy luận khó kiểm chứng từ màu ảnh và delta theo ảnh lớn | Phân biệt số in trên ảnh với số tính lại; bỏ quy nguyên nhân khi thiếu mask/CSV gốc |
| C10 | Tóm tắt | Câu “link giúp/làm” dễ thành khẳng định nhân quả | Diễn đạt là chênh lệch quan sát giữa các run một seed |
| C11 | Mục 4.2.2 | Lặp lại cách diễn đạt nhân quả | Nêu checkpoint nào cao/thấp hơn, giữ giới hạn CI và seed |
| C12 | Phụ lục B.2 | Chưa tách script xác minh hash với loader xác minh model | Ghi rõ verify_checkpoint.py chỉ tính hash; loader kiểm tra variant/bins/step/state_dict |
| C13 | Mục 3.2 | Thiếu chi tiết để phân biệt nội suy trong model và runner | Mô hình PSPNet Modal dùng True, PSPNet Kaggle dùng False; bước resize xác suất cuối của cả hai runner đều dùng True |
| C14 | Mục 2.6 | Công thức loss chưa nói mức trung bình khi accumulation | Làm rõ trung bình loss của từng micro-batch, không nhất thiết bằng trung bình toàn pixel của batch hiệu dụng |
| C15 | Mục 2.4 | Gate tanh có thể bị hiểu thành attention chuẩn hóa | Nêu gate là hệ số vô hướng có dấu, không phải phân phối xác suất trên các nhánh |

Chi tiết nguyên văn trước/sau và nguồn cho từng sửa đổi nằm trong `sua_noi_dung_sau_kiem_toan.json`. Những dòng bổ sung phương pháp không phải số liệu thí nghiệm mới.

## Các con số chính được xác nhận từ output

| Mô hình | mIoU (%) |
|---|---:|
| Modal b6 | 34,4546 |
| Modal b7 | 35,7903 |
| Modal b6_link | 35,0606 |
| Modal b7_link | 35,1730 |
| Modal b6_aspp | 36,2776 |
| Modal b7_aspp | 36,2284 |
| Kaggle FCN–R50 | 22,9235 |
| Kaggle DeepLabV3–R50 | 20,0324 |
| Kaggle PSPNet–R50 | 25,3273 |

Ba CI bootstrap đã lưu thuộc các cặp b7−b6, b7_link−b6_link và b7_aspp−b6_aspp. Không chuyển chúng sang các cặp thêm link/atrous so với bản gốc. Không tạo SD giữa seed hoặc p-value từ các bảng này.

## Những giới hạn vẫn còn và cần giữ trong báo cáo

1. Các output notebook là hồ sơ kết quả được cung cấp, có thể đọc và đối chiếu nhưng không tự chứng minh lịch sử chạy. Chưa tái huấn luyện hay tính lại mIoU từ dataset và model trong đợt này. Vì vậy, không thể cam kết tuyệt đối “không có bất kỳ số liệu bịa nào ở nguồn gốc” chỉ từ notebook đã lưu.
2. Có checkpoint b7 với hash phù hợp. Python gốc của `.venv` không còn tại đường dẫn cấu hình, nên chưa chạy lại model. Hash khớp chứng minh cùng nội dung byte với hash đã ghi, không chứng minh lại mIoU.
3. Chưa tìm thấy CSV/NPZ thống kê gốc cho đủ các run; chưa có đủ checkpoint/init v4 và v5 để so tensor chung. Không tính thêm CI, điểm loại ảnh trùng hoặc xác nhận init chung giữa nhóm atrous và gốc.
4. Cả hai nhóm chỉ có seed 17, ngân sách 10.000 updates. CI theo ảnh không bao phủ biến thiên train; không được gọi 1237 là tối ưu nói chung, hoặc gọi cải thiện link/atrous là kết luận nhân quả đã chứng minh.
5. Notebook ghi 9 ảnh validation trùng byte ảnh train. Split được giữ nguyên; chưa tính mức ảnh hưởng của trùng ảnh lên điểm. Trùng ảnh RGB cũng không tự chứng minh mask của chúng giống nhau.
6. Bản vá all-ignore của Kaggle có trong cả ba notebook nhưng không nằm trong runner được hash. Output cuối đang có resume; chưa xác minh đầy đủ thời điểm áp dụng và số lần bỏ micro-batch xuyên suốt mọi phiên train.
7. Latency forward của T4, L40S và demo CPU không cùng phạm vi đo. Không dùng các cột này làm một bảng xếp hạng tốc độ trực tiếp giữa hai nhóm hay tuyên bố thời gian thực.
8. Tên trường/học phần lấy theo mẫu, giảng viên theo xác nhận người dùng; ngành và chuyên ngành chưa được cung cấp. Lời cam đoan/lời cảm ơn cần chính sinh viên đọc và xác nhận trước khi ký. Đây không phải dữ liệu có thể xác minh từ mã nguồn.

## Hồ sơ kiểm tra kèm theo

- `doi_chieu_toan_bo_so_lieu.json`: 97 phép kiểm tra số liệu và giá trị nguồn.
- `du_lieu_kiem_toan_word.json`: các đoạn, bảng, công thức trích từ Word.
- `sua_noi_dung_sau_kiem_toan.json`: 15 thay đổi có nguồn.
- `ket_qua_ap_dung_kiem_toan.json`: đường dẫn bản sao trước sửa.
- `kiem_tra_word_sau_kiem_toan.json`: số trang, bảng, hình, công thức sau khi Word cập nhật.
- `kiem_tra_trang_sau_kiem_toan/`: ảnh các trang để kiểm tra trình bày.

Các nguồn lý thuyết đã mở và đối chiếu: [PSPNet](https://arxiv.org/abs/1612.01105), [FCN](https://arxiv.org/abs/1411.4038), [DeepLabV3](https://arxiv.org/abs/1706.05587), [ResNet](https://arxiv.org/abs/1512.03385), [TorchVision FCN](https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.segmentation.fcn_resnet50.html), [TorchVision DeepLabV3](https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.segmentation.deeplabv3_resnet50.html) và [semseg tại commit dùng trong dự án](https://github.com/hszhao/semseg/tree/4f274c3f276778228bc14a4565822d46359f0cc8). Một số trang MIT/CVF không truy cập được trong lượt này; không dùng lỗi truy cập đó làm bằng chứng rằng tài liệu không tồn tại.
